analyze verbose;
